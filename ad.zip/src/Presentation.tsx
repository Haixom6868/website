import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence, useScroll, useTransform } from 'motion/react';
import { 
  ChevronDown, 
  MapPin, 
  Utensils, 
  Palette, 
  Compass, 
  Heart,
  ArrowRight,
  Menu,
  X
} from 'lucide-react';
import { cn } from './lib/utils';

// --- Types ---
interface SectionProps {
  id: string;
  title: string;
  subtitle?: string;
  children: React.ReactNode;
  className?: string;
  bgImage?: string;
  overlay?: boolean;
}

// --- Components ---

const Section: React.FC<SectionProps> = ({ id, title, subtitle, children, className, bgImage, overlay = true }) => {
  return (
    <section 
      id={id}
      className={cn(
        "relative min-h-screen flex flex-col items-center justify-center px-6 py-24 overflow-hidden",
        className
      )}
    >
      {bgImage && (
        <div className="absolute inset-0 z-0">
          <img 
            src={bgImage} 
            alt={title}
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
          {overlay && <div className="absolute inset-0 bg-black/40 backdrop-blur-[2px]" />}
        </div>
      )}
      
      <div className="relative z-10 max-w-6xl w-full">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="text-center mb-16"
        >
          <span className="text-imperial font-medium tracking-[0.2em] uppercase text-sm mb-4 block">
            {subtitle}
          </span>
          <h2 className="text-4xl md:text-6xl lg:text-7xl font-serif text-white mb-6">
            {title}
          </h2>
          <div className="w-24 h-1 bg-imperial mx-auto" />
        </motion.div>
        
        {children}
      </div>
    </section>
  );
};

const Card: React.FC<{ title: string; description: string; image: string; icon: React.ReactNode }> = ({ title, description, image, icon }) => (
  <motion.div 
    whileHover={{ y: -10 }}
    className="group relative bg-white rounded-2xl overflow-hidden shadow-xl transition-all duration-500"
  >
    <div className="aspect-[4/5] overflow-hidden">
      <img 
        src={image} 
        alt={title} 
        className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
        referrerPolicy="no-referrer"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-60 group-hover:opacity-80 transition-opacity" />
    </div>
    
    <div className="absolute bottom-0 left-0 right-0 p-8 text-white">
      <div className="flex items-center gap-3 mb-3">
        <div className="p-2 bg-imperial/90 rounded-lg text-white">
          {icon}
        </div>
        <h3 className="text-2xl font-serif">{title}</h3>
      </div>
      <p className="text-sm text-gray-200 line-clamp-3 group-hover:line-clamp-none transition-all duration-500">
        {description}
      </p>
    </div>
  </motion.div>
);

const Quiz: React.FC = () => {
  const [score, setScore] = useState<number | null>(null);
  const [answers, setAnswers] = useState<Record<string, string>>({});

  const questions = [
    {
      id: 'q1',
      question: 'Phở là gì trong văn hóa Việt Nam?',
      options: [
        { label: 'Món ăn quốc hồn quốc túy', value: '1' },
        { label: 'Một loại trang phục', value: '0' }
      ]
    },
    {
      id: 'q2',
      question: 'Áo dài thường được mặc vào dịp nào?',
      options: [
        { label: 'Lễ Tết, cưới hỏi, sự kiện', value: '1' },
        { label: 'Chỉ mặc khi đi ngủ', value: '0' }
      ]
    }
  ];

  const handleSubmit = () => {
    if (Object.keys(answers).length < questions.length) {
      return;
    }
    const total = Object.values(answers).reduce((acc: number, val: string) => acc + parseInt(val), 0);
    setScore(total);
  };

  return (
    <div className="space-y-12">
      {questions.map((q) => (
        <div key={q.id} className="space-y-6">
          <p className="text-2xl font-serif text-imperial">{q.question}</p>
          <div className="grid md:grid-cols-2 gap-4">
            {q.options.map((opt) => (
              <label 
                key={opt.label}
                className={cn(
                  "block p-6 border rounded-2xl cursor-pointer transition-all",
                  answers[q.id] === opt.value 
                    ? "border-imperial bg-imperial/10" 
                    : "border-white/20 hover:border-imperial/50"
                )}
              >
                <input 
                  type="radio" 
                  name={q.id} 
                  value={opt.value} 
                  className="hidden"
                  onChange={(e) => setAnswers({ ...answers, [q.id]: e.target.value })}
                />
                {opt.label}
              </label>
            ))}
          </div>
        </div>
      ))}

      <div className="text-center pt-8">
        <button 
          onClick={handleSubmit}
          disabled={Object.keys(answers).length < questions.length}
          className="bg-imperial text-ink px-12 py-4 rounded-full font-bold uppercase tracking-widest hover:bg-white transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          Xem Kết Quả
        </button>
      </div>

      <AnimatePresence>
        {score !== null && (
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="mt-12 p-10 bg-white/5 rounded-3xl border border-imperial/30"
          >
            <h4 className="text-3xl font-serif text-imperial mb-4">Kết quả của bạn</h4>
            <p className="text-xl font-light">
              Bạn đã đạt {score}/{questions.length} điểm. {score === questions.length ? "Bạn thực sự là một chuyên gia về văn hóa Việt!" : "Hãy tiếp tục khám phá để hiểu thêm về đất nước mình nhé!"}
            </p>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default function Presentation() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { scrollYProgress } = useScroll();
  const scaleX = useTransform(scrollYProgress, [0, 1], [0, 1]);

  const sections = [
    { id: 'tong-quan', label: 'Tổng Quan' },
    { id: 'am-thuc', label: 'Ẩm Thực' },
    { id: 'nghe-thuat', label: 'Nghệ Thuật' },
    { id: 'dia-danh', label: 'Địa Danh' },
    { id: 'tam-hon', label: 'Tâm Hồn' },
  ];

  return (
    <div className="bg-paper min-h-screen selection:bg-lacquer selection:text-white">
      {/* Progress Bar */}
      <motion.div 
        className="fixed top-0 left-0 right-0 h-1 bg-lacquer z-50 origin-left"
        style={{ scaleX }}
      />

      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-40 px-6 py-6 flex justify-between items-center bg-gradient-to-b from-black/50 to-transparent">
        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="text-white font-serif text-2xl tracking-tight"
        >
          Văn Hóa <span className="text-imperial italic">Việt Nam</span>
        </motion.div>

        <div className="hidden md:flex gap-8">
          {sections.map((s) => (
            <a 
              key={s.id} 
              href={`#${s.id}`}
              className="text-white/80 hover:text-imperial text-sm font-medium tracking-widest uppercase transition-colors"
            >
              {s.label}
            </a>
          ))}
        </div>

        <button 
          onClick={() => setIsMenuOpen(true)}
          className="md:hidden text-white p-2"
        >
          <Menu size={24} />
        </button>
      </nav>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div
            initial={{ opacity: 0, x: '100%' }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: '100%' }}
            className="fixed inset-0 z-50 bg-lacquer text-white p-12 flex flex-col justify-center items-center gap-8"
          >
            <button 
              onClick={() => setIsMenuOpen(false)}
              className="absolute top-8 right-8 p-2"
            >
              <X size={32} />
            </button>
            {sections.map((s) => (
              <a 
                key={s.id} 
                href={`#${s.id}`}
                onClick={() => setIsMenuOpen(false)}
                className="text-3xl font-serif hover:text-imperial transition-colors"
              >
                {s.label}
              </a>
            ))}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Hero Section */}
      <section id="tong-quan" className="relative h-screen flex items-center justify-center overflow-hidden">
        <div class="absolute inset-0 z-0">
          <img 
            src="https://picsum.photos/seed/vietnam-hero/1920/1080" 
            alt="Vietnam Landscape"
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-black/50" />
        </div>

        <div className="relative z-10 text-center px-6">
          <motion.span 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-imperial font-medium tracking-[0.4em] uppercase text-sm md:text-base mb-6 block"
          >
            Hành trình khám phá di sản
          </motion.span>
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="text-6xl md:text-8xl lg:text-9xl font-serif text-white mb-8 leading-tight"
          >
            Văn Hóa <br />
            <span className="italic text-imperial">Việt Nam</span>
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.6 }}
            className="max-w-2xl mx-auto text-white/80 text-lg md:text-xl font-light leading-relaxed mb-12"
          >
            Nơi giao thoa giữa truyền thống ngàn năm và nhịp sống hiện đại, 
            tạo nên một bản sắc độc đáo, đậm đà lòng hiếu khách và tinh thần kiên cường.
          </motion.p>
          <motion.a
            href="#am-thuc"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.8 }}
            className="inline-flex items-center gap-3 text-white border border-white/30 px-8 py-4 rounded-full hover:bg-white hover:text-lacquer transition-all duration-300 group"
          >
            Bắt đầu khám phá
            <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
          </motion.a>
        </div>

        <motion.div 
          animate={{ y: [0, 10, 0] }}
          transition={{ repeat: Infinity, duration: 2 }}
          className="absolute bottom-10 left-1/2 -translate-x-1/2 text-white/50"
        >
          <ChevronDown size={32} />
        </motion.div>
      </section>

      {/* Cuisine Section */}
      <Section 
        id="am-thuc" 
        title="Tinh Hoa Ẩm Thực" 
        subtitle="Hương vị quê hương"
        bgImage="https://picsum.photos/seed/vietnam-food-bg/1920/1080"
      >
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <Card 
            title="Phở Việt"
            icon={<Utensils size={20} />}
            image="https://picsum.photos/seed/vietnam-pho/800/1000"
            description="Món ăn quốc hồn quốc túy, kết hợp tinh tế giữa nước dùng thanh ngọt, bánh phở mềm mại và các loại thảo mộc đặc trưng."
          />
          <Card 
            title="Cà Phê Sữa Đá"
            icon={<Utensils size={20} />}
            image="https://picsum.photos/seed/vietnam-coffee/800/1000"
            description="Nét văn hóa vỉa hè độc đáo, cà phê rang đậm đà hòa quyện cùng sữa đặc béo ngậy, biểu tượng của sự thong dong."
          />
          <Card 
            title="Bánh Mì"
            icon={<Utensils size={20} />}
            image="https://picsum.photos/seed/vietnam-banhmi/800/1000"
            description="Sự kết hợp hoàn hảo giữa ẩm thực Pháp và khẩu vị Việt, món ăn đường phố được yêu thích trên toàn thế giới."
          />
        </div>
      </Section>

      {/* Arts Section */}
      <Section 
        id="nghe-thuat" 
        title="Nghệ Thuật & Di Sản" 
        subtitle="Sắc màu truyền thống"
        bgImage="https://picsum.photos/seed/vietnam-art-bg/1920/1080"
      >
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="space-y-8"
          >
            <div className="flex gap-6 items-start">
              <div className="p-4 bg-lacquer text-white rounded-2xl shrink-0">
                <Palette size={32} />
              </div>
              <div>
                <h3 className="text-3xl font-serif text-white mb-4">Áo Dài Truyền Thống</h3>
                <p className="text-white/70 leading-relaxed">
                  Trang phục biểu tượng cho vẻ đẹp dịu dàng, thanh lịch của người phụ nữ Việt Nam. 
                  Áo dài không chỉ là quần áo, mà là cả một câu chuyện về lịch sử và lòng tự hào dân tộc.
                </p>
              </div>
            </div>
            <div className="flex gap-6 items-start">
              <div className="p-4 bg-lacquer text-white rounded-2xl shrink-0">
                <Palette size={32} />
              </div>
              <div>
                <h3 className="text-3xl font-serif text-white mb-4">Múa Rối Nước</h3>
                <p className="text-white/70 leading-relaxed">
                  Loại hình nghệ thuật sân khấu độc đáo ra đời từ nền văn minh lúa nước, 
                  phản ánh sinh động đời sống lao động và tâm linh của người dân Việt.
                </p>
              </div>
            </div>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="relative"
          >
            <div className="aspect-square rounded-3xl overflow-hidden shadow-2xl">
              <img 
                src="https://picsum.photos/seed/vietnam-art/1000/1000" 
                alt="Traditional Art"
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="absolute -bottom-8 -left-8 bg-imperial p-8 rounded-2xl shadow-xl max-w-xs hidden md:block">
              <p className="text-lacquer font-serif text-lg italic">
                "Văn hóa là hồn cốt của dân tộc, còn truyền thống là mạch máu nuôi dưỡng tâm hồn."
              </p>
            </div>
          </motion.div>
        </div>
      </Section>

      {/* Landmarks Section */}
      <Section 
        id="dia-danh" 
        title="Kỳ Quan Thiên Nhiên" 
        subtitle="Vẻ đẹp bất tận"
        bgImage="https://picsum.photos/seed/vietnam-halong-bg/1920/1080"
      >
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="group relative h-[500px] rounded-3xl overflow-hidden">
            <img 
              src="https://picsum.photos/seed/vietnam-halong/1000/1000" 
              alt="Ha Long Bay"
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />
            <div className="absolute bottom-0 p-10">
              <div className="flex items-center gap-2 text-imperial mb-2">
                <MapPin size={16} />
                <span className="text-xs uppercase tracking-widest">Quảng Ninh</span>
              </div>
              <h3 className="text-4xl font-serif text-white mb-4">Vịnh Hạ Long</h3>
              <p className="text-white/70 max-w-md">
                Di sản thiên nhiên thế giới với hàng ngàn đảo đá vôi kỳ vĩ nổi bật trên làn nước xanh ngọc bích.
              </p>
            </div>
          </div>
          
          <div className="group relative h-[500px] rounded-3xl overflow-hidden">
            <img 
              src="https://picsum.photos/seed/vietnam-hoian/1000/1000" 
              alt="Hoi An"
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />
            <div className="absolute bottom-0 p-10">
              <div className="flex items-center gap-2 text-imperial mb-2">
                <MapPin size={16} />
                <span className="text-xs uppercase tracking-widest">Quảng Nam</span>
              </div>
              <h3 className="text-4xl font-serif text-white mb-4">Phố Cổ Hội An</h3>
              <p className="text-white/70 max-w-md">
                Nơi thời gian như ngừng lại giữa những ngôi nhà tường vàng cổ kính và ánh đèn lồng lung linh huyền ảo.
              </p>
            </div>
          </div>
        </div>
      </Section>

      {/* Spirit Section */}
      <section id="tam-hon" className="py-32 bg-paper relative overflow-hidden">
        <div className="max-w-4xl mx-auto px-6 text-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="mb-12 inline-block p-6 bg-lacquer/5 rounded-full"
          >
            <Heart size={48} className="text-lacquer" />
          </motion.div>
          
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-4xl md:text-6xl font-serif text-lacquer mb-8"
          >
            Tâm Hồn & Con Người
          </motion.h2>
          
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="text-xl md:text-2xl text-gray-600 font-light leading-relaxed italic mb-16"
          >
            "Người Việt Nam hiền hậu, mến khách, luôn giữ vững tinh thần lạc quan và kiên cường trước mọi thử thách. 
            Đó chính là sức mạnh nội tại giúp văn hóa Việt trường tồn qua hàng ngàn năm lịch sử."
          </motion.p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            <div className="text-center">
              <h4 className="text-imperial font-serif text-2xl mb-2">Hiếu Khách</h4>
              <p className="text-sm text-gray-500">Luôn chào đón bạn bè quốc tế bằng nụ cười rạng rỡ.</p>
            </div>
            <div className="text-center">
              <h4 className="text-imperial font-serif text-2xl mb-2">Kiên Cường</h4>
              <p className="text-sm text-gray-500">Vươn lên mạnh mẽ từ những thăng trầm lịch sử.</p>
            </div>
            <div className="text-center">
              <h4 className="text-imperial font-serif text-2xl mb-2">Gắn Kết</h4>
              <p className="text-sm text-gray-500">Đề cao giá trị gia đình và tình làng nghĩa xóm.</p>
            </div>
          </div>
        </div>

        {/* Decorative Lotus */}
        <div className="absolute -bottom-24 -right-24 opacity-5 pointer-events-none">
          <Palette size={400} />
        </div>
      </section>

      {/* Quiz Section */}
      <Section 
        id="quiz" 
        title="Kiểm Tra Kiến Thức" 
        subtitle="Bạn hiểu bao nhiêu về Việt Nam?"
        className="bg-ink text-white"
      >
        <div className="max-w-3xl mx-auto">
          <Quiz />
        </div>
      </Section>

      {/* Footer */}
      <footer className="bg-ink text-white py-20 px-6">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row justify-between items-center gap-12">
          <div className="text-center md:text-left">
            <h3 className="text-3xl font-serif mb-4">Văn Hóa Việt Nam</h3>
            <p className="text-white/40 max-w-xs">
              Khám phá và tôn vinh những giá trị truyền thống của dân tộc Việt.
            </p>
          </div>
          
          <div className="flex gap-8">
            <a href="#" className="text-white/60 hover:text-imperial transition-colors">Facebook</a>
            <a href="#" className="text-white/60 hover:text-imperial transition-colors">Instagram</a>
            <a href="#" className="text-white/60 hover:text-imperial transition-colors">Youtube</a>
          </div>
          
          <div className="text-center md:text-right">
            <p className="text-white/40 text-sm">
              &copy; 2026 Hành Trình Di Sản. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
