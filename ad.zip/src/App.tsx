import Presentation from './Presentation';

export default function App() {
  return (
    <main>
      <Presentation />
    </main>
  );
}
